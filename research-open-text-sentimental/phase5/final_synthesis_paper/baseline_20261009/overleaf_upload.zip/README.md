# Overleaf compile note

This bundle is a review draft of an IEEE conference manuscript. It is not a public data archive.

Upload main.tex and references.bib together. Set main.tex as the main file. The document class is IEEEtran. All figures are TikZ inside main.tex, so no image files are required. Paths in the manuscript are relative to this folder.

Study data, post identifiers, and the internal provenance notes are not in this ZIP.
